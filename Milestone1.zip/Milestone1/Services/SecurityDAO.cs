﻿using Milestone1.Models;

using System.Data.SqlClient;

namespace Milestone1.Services
{
	public class SecurityDAO
	{
		private string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Test; Integrated Security=True; Connect Timeout=30; Encrypt=False; TrustServerCertificate=False; ApplicationIntent=ReadWrite; MultiSubnetFailover=False";

		public bool InsertUser(UserModel user)
		{
			bool success = false;
			string sqlStatement = "INSERT INTO dbo.users" +
								  "(FirstName, LastName, Sex, Age, State, Email, Username, Password) " +
								  "VALUES (@FirstName, @LastName, @Sex, @Age, @State, @Email, @Username, @Password)";

			using (SqlConnection connection = new SqlConnection(connectionString))
			{
				SqlCommand command = new SqlCommand(sqlStatement, connection);

				command.Parameters.Add("@FirstName", System.Data.SqlDbType.NVarChar, 50).Value = user.FirstName;
				command.Parameters.Add("@LastName", System.Data.SqlDbType.NVarChar, 50).Value = user.LastName;
				command.Parameters.Add("@Sex", System.Data.SqlDbType.NVarChar, 10).Value = user.Sex;
				command.Parameters.Add("@Age", System.Data.SqlDbType.Int).Value = user.Age;
				command.Parameters.Add("@State", System.Data.SqlDbType.NVarChar, 50).Value = user.State;
				command.Parameters.Add("@Email", System.Data.SqlDbType.NVarChar, 100).Value = user.Email;
				command.Parameters.Add("@Username", System.Data.SqlDbType.NVarChar, 20).Value = user.Username;
				command.Parameters.Add("@Password", System.Data.SqlDbType.NVarChar, 100).Value = user.Password; // Remember to hash passwords in real applications

				try
				{
					connection.Open();
					int result = command.ExecuteNonQuery();
					success = result > 0;
				}
				catch (Exception ex)
				{
					// Consider logging the exception
					Console.WriteLine(ex.Message);
				}
			}

			return success;
		}
	}
}
